"""Workspace-local pyOCD entry point. No operations are implicit."""
from pathlib import Path
import runpy
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / 'pyocd_deps'))
runpy.run_module('pyocd', run_name='__main__')
