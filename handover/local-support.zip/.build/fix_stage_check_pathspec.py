from pathlib import Path
p=Path('.build/check_stage_before_commit.py');s=p.read_text(encoding='utf-8-sig');s=s.replace("['git','diff','--cached','--check','--','.','!:Drivers']", "['git','diff','--cached','--check','--','Core','tools','tests','docs','.gitignore','MDK-ARM']");p.write_text(s,encoding='utf-8')
