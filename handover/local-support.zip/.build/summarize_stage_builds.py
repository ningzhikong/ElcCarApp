from pathlib import Path
import json,re
root=Path.cwd();rows=[]
for mode,folder in [('normal','firmware'),('ground','ground_test'),('line','ground_line'),('imu','imu_test'),('ir','ir_test')]:
 p=root/'.build'/folder;d=json.loads((p/'build_id.json').read_text());m=(p/'firmware.map').read_text(errors='replace');rw=int(re.search(r'Total RW  Size.*?([0-9]+) \(',m).group(1));rom=int(re.search(r'Total ROM Size.*?([0-9]+) \(',m).group(1));rows.append(dict(mode=mode,build_id=d['build_id'],rw_bytes=rw,rom_bytes=rom));assert rw<=20480 and rom<=65536
(root/'.build/stage_20261026_builds.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
