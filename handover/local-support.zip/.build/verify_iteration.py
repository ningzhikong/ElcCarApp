from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
folder = root / '.build/iteration_smoke'
folder.mkdir(exist_ok=True)
candidate = folder / 'candidate.json'
candidate.write_text(json.dumps(dict(kp_left=2.2, ki_left=.33, kp_right=2.2, ki_right=.33,
                                    stop=False, reason='host workflow check', expected_effect='fictional model only')))
subprocess.run([sys.executable, 'tools/autotune/tune.py', '--simulate', '--candidate-file', str(candidate),
                '--sign-left', '1', '--sign-right', '-1', '--kp-left', '2', '--ki-left', '.3',
                '--kp-right', '2', '--ki-right', '.3', '--peak', '5', '--pwm-limit', '100',
                '--output', str(folder)], cwd=root, check=True)
summary = max(folder.glob('search_*/summary.json'), key=lambda p: p.stat().st_mtime)
report = json.loads(summary.read_text(encoding='utf-8'))
assert report['source'] == 'host_mock'
assert report['best_experiments'] and all((summary.parent / r['trace_file']).is_file() for r in report['best_experiments'])
rejected_output = folder / 'rejected_profile.h'
rejection = subprocess.run([sys.executable, 'tools/autotune/export_profile.py', str(summary),
                            '--output', str(rejected_output)], cwd=root, capture_output=True, text=True)
assert rejection.returncode == 2 and not rejected_output.exists() and 'real_motor' in rejection.stderr
print('End-to-end host mock search and non-export policy: PASS')
includes = [root / p for p in ('Core/Inc', 'tests', 'Drivers/STM32F1xx_HAL_Driver/Inc',
            'Drivers/STM32F1xx_HAL_Driver/Inc/Legacy', 'Drivers/CMSIS/Device/ST/STM32F1xx/Include',
            'Drivers/CMSIS/Include')]
subprocess.run([r'D:\Keil\ARM\ARMCC\bin\armcc.exe', '--cpu', 'Cortex-M3', '--c99', '-O1',
                '--library_type=microlib', '-D__MICROLIB', '-DSTM32F103xB', '-DUSE_HAL_DRIVER',
                '-DCAR_TUNED_CONFIG_HEADER="tuned_profile_fixture.h"',
                *[f'-I{p}' for p in includes], '-c', str(root / 'Core/Src/control.c'),
                '-o', str(root / '.build/tests/control_tuned_arm.o')], cwd=root, check=True)
print('ARMCC5 tuned-profile production branch compile (object only): PASS')
