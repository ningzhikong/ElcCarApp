from pathlib import Path
import hashlib,json,zipfile,re
root=Path.cwd();out=root/'handover';out.mkdir(exist_ok=True)
groups={}
for name,base in [('hardware-evidence','.build/hardware_checks'),('validated-baselines','.build/baselines')]:
 groups[name]=[p for p in (root/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
groups['firmware-and-validation']=[]
for base in ['firmware','ground_test','ground_line','imu_test','ir_test','tests']:
 groups['firmware-and-validation'] += [p for p in (root/'.build'/base).rglob('*') if p.is_file() and p.suffix.lower() not in ('.o','.exe','.pyc') and '__pycache__' not in p.parts]
groups['local-support']=[p for p in (root/'.build').glob('*') if p.is_file() and p.suffix.lower() in ('.py','.json','.txt','.nul')]
patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'gh[pousr]_[A-Za-z0-9]{30,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{40,}'),re.compile(rb'AKIA[0-9A-Z]{16}')]
selected=[p for files in groups.values() for p in files]
scan=selected+[p for base in ['Core','tools','tests','docs'] for p in (root/base).rglob('*') if p.is_file() and '.build' not in p.parts and '__pycache__' not in p.parts]
issues=[]
for p in scan:
 if p.suffix.lower() in ('.py','.json','.txt','.log','.md','.c','.h','.csv','.xml','.yml','.yaml','.ini','.cfg'):
  if any(pattern.search(p.read_bytes()) for pattern in patterns):issues.append(p.relative_to(root).as_posix())
if issues:raise RuntimeError('Credential-like patterns in: '+str(issues))
manifest={'date':'2026-10-26','archives':[],'files':[],'excluded':['Git internals and duplicate worktrees','installed dependency caches','object files and test executables','IDE user state','assistant memory and temporary review','external WeChat media originals']}
for name,files in groups.items():
 files=sorted(set(files));zpath=out/(name+'.zip')
 with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:
   relative=p.relative_to(root).as_posix();data=p.read_bytes();z.writestr(relative,data)
   manifest['files'].append({'archive':name+'.zip','path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
 sha=hashlib.sha256(zpath.read_bytes()).hexdigest();limit=45*1024*1024;parts=[]
 if zpath.stat().st_size>limit:
  with zpath.open('rb') as f:
   idx=1
   while data:=f.read(limit):
    part=out/(zpath.name+f'.part{idx:03d}');part.write_bytes(data);parts.append({'name':part.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});idx+=1
  zpath.unlink() # This newly created local ZIP is replaced by its verified split parts.
 else:parts=[{'name':zpath.name,'bytes':zpath.stat().st_size,'sha256':sha}]
 manifest['archives'].append({'name':name+'.zip','sha256':sha,'parts':parts,'files':len(files)})
 print(name,len(files),round(sum(p['bytes'] for p in parts)/1048576,2),'MiB')
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('All archives checked; credential-pattern scan clear; files:',len(manifest['files']))
