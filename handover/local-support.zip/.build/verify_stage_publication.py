from pathlib import Path
import subprocess,json
root=Path.cwd();stage=root/'.build/github-code-only'
def git(args,cwd=root):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
before=json.loads((root/'.build/stage_20261026_remote_before.json').read_text())
after={line.split()[1]:line.split()[0] for line in git(['-c','http.sslBackend=openssl','ls-remote','--heads','origin']).splitlines()}
public=git(['rev-parse','HEAD'],stage);local=git(['rev-parse','HEAD'])
assert after['refs/heads/codex/stage-20261018']==public
assert all(after.get(name)==sha for name,sha in before.items() if name!='refs/heads/codex/stage-20261018')
assert not git(['status','--porcelain']) and not git(['status','--porcelain'],stage)
files=git(['ls-tree','-r','--name-only','HEAD'],stage).splitlines()
assert len(files)==994 and not any(p.lower().endswith('.md') for p in files)
assert sum(p.startswith('tests/') for p in files)==23
assert 'tools/pyocd_local.py' in files and 'Core/Src/ground_test.c' in files
result={'published_commit':public,'local_commit':local,'branch':'codex/stage-20261018','remote_verified':True,'other_remote_branches_unchanged':True,'files':994,'test_source_files':23,'host_checks':302,'build_modes':['normal','ground','line','imu','ir'],'local_worktree_clean':True,'stage_worktree_clean':True,'summary_local':'docs/阶段总结-2026-10-26.md','commit_url':'https://github.com/ningzhikong/ElcCarApp/commit/'+public}
(root/'.build/stage_20261026_publication_receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
