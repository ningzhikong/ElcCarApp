from pathlib import Path
import subprocess,json
root=Path.cwd();stage=root/'.build/github-code-only'
manifest=json.loads((root/'.build/stage_20261026_manifest.json').read_text())
files=set(x.decode('utf-8') for x in subprocess.check_output(['git','ls-files','-z'],cwd=stage).split(b'\0') if x)
assert files==set(manifest['source_files']), (len(files),len(manifest['source_files']))
assert not any(p.lower().endswith('.md') or p.startswith(('.build/','.review_tmp/','MDK-ARM/ElcCarApp/','MDK-ARM/DebugConfig/')) for p in files)
assert len([p for p in files if p.startswith('tests/')])==23
for cwd in (root,stage):
 result=subprocess.run(['git','diff','--cached','--check','--','Core','tools','tests','docs','.gitignore','MDK-ARM'],cwd=cwd,capture_output=True,text=True)
 assert result.returncode==0,result.stdout+result.stderr
local=[x.decode('utf-8') for x in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).split(b'\0') if x]
assert all(p.startswith(('Core/','tools/','tests/','docs/阶段总结-2026-10-26.md')) for p in local)
remote=subprocess.check_output(['git','-c','http.sslBackend=openssl','ls-remote','--heads','origin'],cwd=root,text=True)
before={line.split()[1]:line.split()[0] for line in remote.splitlines()}
assert before['refs/heads/codex/stage-20261018']=='1dc01a77bad1f263826628fcc91998956d84fddc'
(root/'.build/stage_20261026_remote_before.json').write_text(json.dumps(before,indent=2))
print(json.dumps({'local_staged_files':len(local),'public_files':len(files),'tests_source_files':23,'remote_heads_before':before},indent=2))
