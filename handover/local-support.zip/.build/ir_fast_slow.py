import sys,json,time,struct
from pathlib import Path
from datetime import datetime
sys.path.insert(0,'.build/pyocd_deps')
from pyocd.core.helpers import ConnectHelper
from elftools.elf.elffile import ELFFile
from intelhex import IntelHex
out=Path('.build/ground_line')
with (out/'ElcCarApp.axf').open('rb') as f:
 syms={s.name:(s['st_value'],s['st_size']) for s in ELFFile(f).get_section_by_name('.symtab').iter_symbols()}
h=IntelHex(str(out/'ElcCarApp.hex')); aa=h.addresses(); first=min(aa)
opts={'target_override':'stm32f103c8','pack':[r'D:\Keil\ARM\Pack\Keil\STM32F1xx_DFP\2.2.0'],'connect_mode':'attach','auto_unlock':False,'resume_on_disconnect':False,'frequency':1000000,'no_config':True}
r={'build_id':json.loads((out/'build_id.json').read_text())['build_id'],'fast':[],'slow':[]}
with ConnectHelper.session_with_chosen_probe(unique_id='37FF71064E573436189D1843',blocking=False,options=opts) as s:
 t=s.target; actual=t.read_memory_block8(first,max(aa)-first+1)
 assert all(actual[a-first]==h[a] for a in aa)
 for i in range(80):
  state=t.read32(syms['ground_result'][0]+4)
  assert state==0,'Not in READY; refusing static test'
  assert t.read32(0x4000043c)==t.read32(0x40000440)==0
  frame=struct.unpack('<4If2I',bytes(t.read_memory_block8(syms['ground_ir'][0],28)))
  r['fast'].append(dict(zip(('filtered','black','tick','valid','error','raw','noisy'),frame)))
  time.sleep(.025)
 a_original=t.read32(0x4001080c)&0x1800; b_original=t.read32(0x40010c0c)&0x20
 t.halt()
 try:
  assert t.read32(syms['ground_result'][0]+4)==0
  assert t.read32(0x4000043c)==t.read32(0x40000440)==0
  for repeat in range(3):
   for ch in range(8):
    av=(0x1000 if ch&2 else 0)|(0x800 if ch&4 else 0);bv=0x20 if ch&1 else 0
    t.write32(0x40010810,av|((0x1800^av)<<16));t.write32(0x40010c10,bv|((0x20^bv)<<16))
    values=[]
    for j in range(12):
     time.sleep(.005)
     ai=t.read32(0x40010808); bi=t.read32(0x40010c08)
     values.append({'pa2':(ai>>2)&1,'selector':((bi>>5)&1)|(((ai>>12)&1)<<1)|(((ai>>11)&1)<<2)})
    r['slow'].append({'repeat':repeat,'channel':ch+1,'samples':values})
 finally:
  t.write32(0x40010810,a_original|((0x1800^a_original)<<16));t.write32(0x40010c10,b_original|((0x20^b_original)<<16))
  assert t.read32(0x4000043c)==t.read32(0x40000440)==0
  t.resume()
 r['cpu_after']=t.get_state().name
 r['pwm_after']=[t.read32(0x4000043c),t.read32(0x40000440)]
r['summary']={'raw_patterns':sorted(set(x['raw'] for x in r['fast'])),'filtered_patterns':sorted(set(x['filtered'] for x in r['fast'])),'noisy_frames':sum(x['noisy']!=0 for x in r['fast']),'slow_by_channel':[{'channel':i+1,'high':sum(v['pa2'] for row in r['slow'] if row['channel']==i+1 for v in row['samples']),'total':36,'selector_errors':sum(v['selector']!=i for row in r['slow'] if row['channel']==i+1 for v in row['samples'])} for i in range(8)]}
p=Path('.build/hardware_checks')/('ir_fast_slow_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json');p.write_text(json.dumps(r,indent=2))
print(json.dumps(r['summary'],indent=2));print('pwm_after',r['pwm_after']);print('saved',str(p))
