from pathlib import Path
import json
root=Path.cwd();stage=root/'.build/github-code-only'
for folder in ('firmware','ground_test'):
 local=json.loads((root/'.build'/folder/'build_id.json').read_text())
 public=json.loads((stage/'.build'/folder/'build_id.json').read_text())
 assert local==public,(folder,local,public)
message='''Validate heading-hold driving and staged 130 RPM commissioning

Correct the measured yaw mapping to X-axis positive-left and add bounded
heading PD for the independent ground straight-line firmware. Preserve
wheel-specific 1080/1320 CPR, full-tick speed/PWM statistics, stopped-only
raw capture, motor-disabled IMU diagnostics and detailed calibration reports.

Validation: 302 host checks (213 C scenarios, 89 Python tests) pass. Normal,
ground, line, IMU and IR ARMCC5 builds fit the STM32F103C8 memory limits.
An independent publication checkout also passes the tests and reproduces
the normal and ground build IDs.

Hardware evidence: one 90 RPM ground run visibly drove straight and ended
at +2.62 degrees. The 100 and 130 RPM raised-wheel checks pass. The 130 RPM
ground run held direction before a confirmed external disturbance at the
end triggered the existing 25-degree heading stop. An uninterrupted 130 RPM
ground repeat and 150 RPM testing remain outstanding. Intermittent startup
calibration failure remains under investigation; thresholds are unchanged.

Normal routes retain 20 RPM/PWM150. Only the dedicated ground experiment
uses 130 RPM/PWM450 with a two-second ramp and ten-second maximum run.
'''
(root/'.build/local_stage_commit.txt').write_text(message+'\nKeep the milestone summary in local Git with the regression source.\n',encoding='utf-8')
(root/'.build/github_stage_commit.txt').write_text(message+'\nPublish full firmware, diagnostic tools and regression source as requested.\nExclude Markdown, runtime data, generated output and local caches.\n',encoding='utf-8')
print('Normal and ground build IDs reproduced; commit messages prepared.')
