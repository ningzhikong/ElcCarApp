import sys,json,time,struct
from pathlib import Path
from datetime import datetime
sys.path.insert(0,'.build/pyocd_deps')
from pyocd.core.helpers import ConnectHelper
from elftools.elf.elffile import ELFFile
from intelhex import IntelHex
out=Path('.build/ground_line')
with (out/'ElcCarApp.axf').open('rb') as f:
 syms={s.name:(s['st_value'],s['st_size']) for s in ELFFile(f).get_section_by_name('.symtab').iter_symbols()}
h=IntelHex(str(out/'ElcCarApp.hex'));aa=h.addresses();first=min(aa)
opts={'target_override':'stm32f103c8','pack':[r'D:\Keil\ARM\Pack\Keil\STM32F1xx_DFP\2.2.0'],'connect_mode':'attach','auto_unlock':False,'resume_on_disconnect':False,'frequency':1000000,'no_config':True}
rows=[];start=time.monotonic()
with ConnectHelper.session_with_chosen_probe(unique_id='37FF71064E573436189D1843',blocking=False,options=opts) as s:
 t=s.target;actual=t.read_memory_block8(first,max(aa)-first+1)
 assert all(actual[a-first]==h[a] for a in aa)
 start=time.monotonic()
 while time.monotonic()-start<20:
  state=t.read32(syms['ground_result'][0]+4)
  assert state==0,'Not READY'
  a=struct.unpack('<4If2I',bytes(t.read_memory_block8(syms['ground_ir'][0],28)))
  rows.append(a)
  time.sleep(.01)
 assert t.read32(0x4000043c)==t.read32(0x40000440)==0
 control=struct.unpack('<5I4i6f',bytes(t.read_memory_block8(syms['current'][0],60)))
summary={'duration_seconds':time.monotonic()-start,'host_samples':len(rows),'unique_firmware_ticks':len(set(x[2] for x in rows)),'raw_patterns':sorted(set(x[5] for x in rows)),'filtered_patterns':sorted(set(x[0] for x in rows)),'raw_changes':sum(a[5]!=b[5] for a,b in zip(rows,rows[1:])),'filtered_changes':sum(a[0]!=b[0] for a,b in zip(rows,rows[1:])),'noisy_samples':sum(x[6]!=0 for x in rows),'invalid_samples':sum(x[3]!=1 for x in rows),'control_fault':control[3],'pwm':[control[13],control[14]]}
p=Path('.build/hardware_checks')/('ir_stability_20s_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json');p.write_text(json.dumps({'summary':summary,'fields':['filtered','black_count','tick_ms','valid','error','raw','noisy'],'samples':rows},indent=2))
print(json.dumps(summary,indent=2));print(str(p))
