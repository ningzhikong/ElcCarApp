from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path.cwd();stage=(root/'.build/github-code-only').resolve()
assert (stage/'.git').is_file() and stage.is_relative_to(root/'.build')
def tracked(cwd):return set(p.decode('utf-8') for p in subprocess.check_output(['git','ls-files','-z'],cwd=cwd).split(b'\0') if p)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=stage).strip(),'Publication worktree must be clean'
paths=[p.decode('utf-8') for p in subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).split(b'\0') if p]
def allowed(path):
 p=Path(path);parts=p.parts
 if p.suffix.lower()=='.md' or '__pycache__' in parts:return False
 if parts[0] in ('Core','Drivers','tools','tests'):return True
 if parts[0]=='MDK-ARM':return p.suffix.lower() in ('.uvprojx','.s','.h','.scvd') and 'ElcCarApp' not in parts[1:-1] and 'DebugConfig' not in parts
 return path in ('.gitignore','.mxproject','ElcCarApp.ioc')
selected=sorted(set(p for p in paths if allowed(p)))
assert not (tracked(stage)-set(selected)), 'Unexpected prior tracked publication files'
for name in selected:
 if name=='.gitignore':continue
 src=root/name;dst=stage/name
 assert dst.resolve().is_relative_to(stage) and src.is_file()
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
ignore=(root/'.gitignore').read_text(encoding='utf-8')+'\n# Generated IDE state and local tooling; regression source is published.\nMDK-ARM/DebugConfig/\nMDK-ARM/*.lst\n.workbuddy/\n'
(stage/'.gitignore').write_text(ignore,encoding='utf-8')
for name in selected:
 if name!='.gitignore':assert (root/name).read_bytes()==(stage/name).read_bytes(),name
assert any(p.startswith('tests/') for p in selected) and 'tools/pyocd_local.py' in selected and 'Core/Src/ground_test.c' in selected
manifest={'stage':str(stage),'files':len(selected),'tests':sum(p.startswith('tests/') for p in selected),'source_files':selected,'excluded':['Markdown','build output','IDE user state','temporary review/cache files']}
(root/'.build/stage_20261026_manifest.json').write_text(json.dumps(manifest,indent=2))
(root/'.build/stage_20261026_paths.nul').write_bytes(b''.join(p.encode('utf-8')+b'\0' for p in selected))
print(json.dumps({k:v for k,v in manifest.items() if k!='source_files'},indent=2))
