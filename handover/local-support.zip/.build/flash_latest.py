import sys,json,subprocess,hashlib,time
from pathlib import Path
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'.build/pyocd_deps'))
from pyocd.core.helpers import ConnectHelper
from intelhex import IntelHex
out=ROOT/'.build/firmware'
stamp=time.strftime('%Y%m%d_%H%M%S')
record=ROOT/'.build/hardware_checks'/('latest_flash_'+stamp)
record.mkdir()
identity=json.loads((out/'build_id.json').read_text())
h=IntelHex(str(out/'ElcCarApp.hex'))
addresses=h.addresses()
assert identity['mode']=='normal' and addresses and all(0x08000000<=a<0x08010000 for a in addresses)
opts={'target_override':'stm32f103c8','pack':[r'D:\Keil\ARM\Pack\Keil\STM32F1xx_DFP\2.2.0'],'connect_mode':'attach','auto_unlock':False,'resume_on_disconnect':False,'frequency':1000000,'no_config':True}
uid='37FF71064E573436189D1843'
with ConnectHelper.session_with_chosen_probe(unique_id=uid,blocking=False,options=opts) as s:
 t=s.target
 t.halt()
 t.write32(0x4000043c,0);t.write32(0x40000440,0)
 assert t.read32(0x4000043c)==t.read32(0x40000440)==0
 (record/'before_flash.bin').write_bytes(bytes(t.read_memory_block8(0x08000000,0x10000)))
subprocess.run([sys.executable,str(ROOT/'.build/pyocd_local.py'),'load','--no-config','--pack',opts['pack'][0],'-t','stm32f103c8','-u',uid,'-f','1000000','-M','halt','-O','auto_unlock=false','-O','resume_on_disconnect=false','--no-reset','-e','sector',str(out/'ElcCarApp.hex')],check=True)
with ConnectHelper.session_with_chosen_probe(unique_id=uid,blocking=False,options=opts) as s:
 t=s.target;t.halt()
 first,last=min(addresses),max(addresses)
 actual=bytes(t.read_memory_block8(first,last-first+1))
 assert all(actual[a-first]==h[a] for a in addresses),'Flash mismatch'
 (record/'readback.bin').write_bytes(actual)
 result={**identity,'verified_bytes':len(addresses),'sha256':hashlib.sha256(actual).hexdigest(),'state':t.get_state().name,'probe':uid}
 (record/'verification.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result))
print('Record:',record)
